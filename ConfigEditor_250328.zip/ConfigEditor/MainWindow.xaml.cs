﻿using APS.WPF.SHEET;
using Kornic.BlockControlFoundation;
using Microsoft.WindowsAPICodePack.Dialogs;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Input;

namespace ConfigEditor
{
	/// <summary>
	/// 
	/// </summary>
	public partial class MainWindow : Window
	{
		#region Class constants
		/// <summary>
		/// 
		/// </summary>
		public const string DEF_STARTUP_PATH = @"..\ConfigFile\";
		/// <summary>
		/// 
		/// </summary>
		public const string DEF_STARTUP = "_StartUp.xml";
		#endregion

		#region Class members

		private Configurator m_configurator;

		#endregion

		#region Class properties
		/// <summary>
		/// 
		/// </summary>
		public PLCManager PLCManager
		{
			get
			{
				return m_configurator.PLCManager;
			}
		}
		/// <summary>
		/// 
		/// </summary>
		public SvidManager SvidManager
		{
			get
			{
				return m_configurator.SvidManager;
			}
		}
		#endregion

		#region Class initialization
		/// <summary>
		/// 
		/// </summary>
		public MainWindow()
		{
			InitializeComponent();

			m_configurator = new Configurator(this);

			Initialize();
		}

		/// <summary>
		/// 
		/// </summary>
		public void Initialize()
		{
			bool bSuccess = false;
			m_configurator = new Configurator(this);

			Initialize_Sheet();
			//bSuccess = m_configurator.Initialize(string.Format("{0}{1}", DEF_STARTUP_PATH, "_StartUp.xml"));

			//m_svidManager = new SvidManager(this);
			//bSuccess = m_svidManager.Initialize(m_sUtilityPath, m_sSvidPath, m_iSvidDay);



		}

		private bool Initialize_Sheet()
		{
			try
			{
				var hashSheet = new Dictionary<int, spColDefaultStyle>();

				var sp0 = new spColDefaultStyle(m_spreadUtility.DefaultStyle);
				sp0._dataFormat = unvell.ReoGrid.DataFormat.CellDataFormatFlag.Text;
				sp0._hAlign = unvell.ReoGrid.ReoGridHorAlign.Center;
				sp0._vAlign = unvell.ReoGrid.ReoGridVerAlign.Middle;
				sp0._indent = 2;
				sp0._IsReadOnly = true;
				hashSheet.Add(-1, sp0);

				var sp1 = new spColDefaultStyle(m_spreadUtility.DefaultStyle);
				sp1._dataFormat = unvell.ReoGrid.DataFormat.CellDataFormatFlag.Text;
				sp1._hAlign = unvell.ReoGrid.ReoGridHorAlign.Left;
				sp1._vAlign = unvell.ReoGrid.ReoGridVerAlign.Middle;
				sp1._indent = 2;
				sp1._IsReadOnly = true;
				hashSheet.Add(1, sp1);


				m_spreadUtility.Initialize(hashSheet);
				//m_spreadUtility.RowCount = 0;

				return true;
			}
			catch (Exception ex)
			{
				//LogManager.ErrorWriteLog(ex.ToString());

				return false;
			}
		}
		#endregion

		#region Class private methods
		#endregion

		#region Class public methods

		#endregion

		#region Class event handler
		private void OnSelectClick(object sender, RoutedEventArgs e)
		{
			try
			{

				CommonOpenFileDialog Dialog = new CommonOpenFileDialog();


				Dialog.InitialDirectory = @"D:";
				Dialog.IsFolderPicker = true;
				Dialog.Title = "Select ConfigFile";

				if (Dialog.ShowDialog() == CommonFileDialogResult.Ok)
				{
					string m_sNewProjectFullPath = Dialog.FileName;

					if (!m_sNewProjectFullPath.Contains("ConfigFile"))
					{
						DirectoryInfo di = new DirectoryInfo(m_sNewProjectFullPath);
						DirectoryInfo sSubdi = di.GetDirectories().FirstOrDefault(x => x.Name.Contains("ConfigFile"));

						if (!(sSubdi is null) && sSubdi.Exists)
						{
							m_sNewProjectFullPath = sSubdi.FullName;

						}

					}
					//Common.PlcConfigFileExistCheck
					if (!m_sNewProjectFullPath.Contains("ConfigFile"))
					{
						MessageBox.Show("ConfigFile을 선택해 주세요.");
						return;
					}

					bool bSuccess = m_configurator.Initialize(m_sNewProjectFullPath, "_StartUp.xml");

					if (bSuccess)
					{
						UISheetUtility();
					}

				}
			}
			catch (Exception)
			{

				throw;
			}
		}
		/// <summary>
		/// 
		/// </summary>
		private void OnEditClick(object sender, RoutedEventArgs e)
		{
			if (m_spreadUtility.Readonly)
			{
				m_spreadUtility.Readonly = false;
			}
			else
			{
				m_spreadUtility.Readonly = true;
			}
		}
		/// <summary>
		/// 
		/// </summary>
		private void OnSaveClick(object sender, RoutedEventArgs e)
		{
			//Sheet -> Xml Write
		}
		/// <summary>
		/// 
		/// </summary>
		private void UISheetUtility()
		{
			//string[] sKey = new string[SvidManager.hashSvidKeyToData.Count];

			m_spreadUtility.RowCount = SvidManager.hashSvidKeyToData.Count;// sKey.Length;
			int iSheetIndex = 0;

			foreach (var svid in SvidManager.hashSvidKeyToData)
			{
				StringBuilder sb = new StringBuilder();
				string sKey = svid.Key.ToString();
				string sName = svid.Value.sPLC_NAME;
				string sFormat = svid.Value.sFORMAT;
				string sType = svid.Value.sTYPE;
				string sUnit = svid.Value.sUNIT;
				string sRange = svid.Value.sRANGE;
				string sDot = svid.Value.sDOT;
				string sSigned = svid.Value.sSIGNED;
				string sLocal = svid.Value.sLOCAL;

				sb.Append(string.Format("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\t{8}\t", sKey, sName, sFormat, sType, sUnit, sRange, sDot, sSigned, sLocal));
				m_spreadUtility.SetClipValue(iSheetIndex++, 0, 1, 5, sb.ToString());
			}
		}



		#endregion

		#region class utility methods
		/// <summary>
		/// 
		/// </summary>
		private void UIWindowMouseDown(object sender, MouseButtonEventArgs e)
		{
			if (e.ChangedButton == MouseButton.Left)
			{
				DragMove();
			}
		}
		#endregion

	}
}
