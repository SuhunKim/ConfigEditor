﻿#region Usings
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Diagnostics;
#endregion

namespace Kornic.BlockControlFoundation
{
  /// <summary>
  /// 
  /// </summary>
  public class clSVID
  {
    #region class constants

    #endregion

    #region class members
    /// <summary>
    /// 
    /// </summary>
    public string sId;
    /// <summary>
    /// 
    /// </summary>
    public string sPLC_NAME;
    /// <summary>
    /// 
    /// </summary>
    public string sFORMAT;
    /// <summary>
    /// 
    /// </summary>
    public string sUNIT;
    /// <summary>
    /// 
    /// </summary>
    public string sRANGE;
    /// <summary>
    /// 
    /// </summary>
    public string sLOCAL;
    /// <summary>
    /// 
    /// </summary>
    public string sDOT;
    /// <summary>
    /// 
    /// </summary>
    public bool bDOT_CUT;
    /// <summary>
    /// 
    /// </summary>
    public string sSIGNED;
    /// <summary>
    /// 
    /// </summary>
    public string sTYPE;
    #endregion
  }
}
